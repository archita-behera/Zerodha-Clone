import React from "react";

function Hero() {
  return (
    <div className="container p-5 mb-5">
      <div className="row text-center justify-content-center">
        <div className="col-lg-8 col-md-10 col-12">
          <img
            src="media/images/homeHero.png"
            alt="Hero Image"
            className="img-fluid mb-4"
          />
          <h1 className="mt-4">Invest in everything</h1>
          <p>
            Online platform to invest in stocks, derivatives, mutual funds, and
            more
          </p>
          <button
            className="p-2 btn btn-primary fs-5 mb-5"
            style={{ width: "100%", maxWidth: "200px", margin: "0 auto" }}
          >
            Signup Now
          </button>
        </div>
      </div>
    </div>
  );
}

export default Hero;
